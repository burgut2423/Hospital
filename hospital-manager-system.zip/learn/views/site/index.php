<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
            <b>ILTIMOS TIZMGA KIRING !!</b>
    </div>
         <h1 class="active text-center text-danger  ">Raxmat!!</h1>
</div>
